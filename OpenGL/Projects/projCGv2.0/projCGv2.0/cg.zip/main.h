#ifndef _MAIN_H_
#define _MAIN_H_

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 700

#define WINDOW_POS_X 0
#define WINDOW_POS_Y 0


#endif