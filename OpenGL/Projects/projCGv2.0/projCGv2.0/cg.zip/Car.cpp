#include <iostream>

#include "GL/glut.h"
#include "generic.h"

#include "Car.h"

void Car::draw()
{
	/*
	//desenho da parte de tras do carro
	glColor3f(changeScale(140), changeScale(226), changeScale(255));
	glutSolidCube(0.1);

	//desenho da parte da frente do carro
	glColor3f(0, changeScale(191), changeScale(255));
	glTranslatef(0, -0.09, 0);
	glutSolidCube(0.08);

	//desenho da roda da frente direita.
	glTranslatef(-0.04, 0, 0);
	glRotatef(90, 0, 1, 0);
	glColor3f(0, 0, 0);
	glutSolidTorus(0.006, 0.015, 50, 50);

	glLoadIdentity();

	//desenho da roda da frente esquerda.
	glRotatef(90, 0, 1, 0);
	glTranslatef(0.1,0,0);
	glutSolidTorus(0.006,0.015,50, 50);*/

	
	glPushMatrix();
	glTranslatef(0, 0, 0);
	glRotatef(0, 0, 0, 0);
	glScalef(0.1, 0.1, 0.1);

	//frente
	glColor3f(0.5, 0.5, 0.5);
	glPushMatrix();
	glTranslatef(-0.5, 0, 0.35);
	glScalef(1.0, 1.0, 0.5);
	glutSolidCube(1.0);
	glPopMatrix();

	//traseira
	glColor3f(0.7, 0.7, 0.7);
	glPushMatrix();
	glTranslatef(0.5, 0, 0.6);
	glScalef(1.0, 1.0, 1.0);
	glutSolidCube(1.0);
	glPopMatrix();

	//roda fronteira esquerda
	glColor3f(0.1, 0.1, 0.1);
	glPushMatrix();
	glTranslatef(-0.5, -0.5, 0.3);
	glRotatef(90, 1, 0, 0);
	glScalef(0.3, 0.3, 0.3);
	glutSolidTorus(0.5, 0.6, 50, 50);
	glPopMatrix();

	//roda fronteira direita
	glColor3f(0.1, 0.1, 0.1);
	glPushMatrix();
	glTranslatef(-0.5, 0.5, 0.3);
	glRotatef(90, 1, 0, 0);
	glScalef(0.3, 0.3, 0.3);
	glutSolidTorus(0.5, 0.6, 50, 50);
	glPopMatrix();

	//roda dianteira direita
	glColor3f(0.1, 0.1, 0.1);
	glPushMatrix();
	glTranslatef(0.5, 0.5, 0.3);
	glRotatef(90, 1, 0, 0);
	glScalef(0.3, 0.3, 0.3);
	glutSolidTorus(0.5, 0.6, 50, 50);
	glPopMatrix();

	//roda dianteira esquerda
	glColor3f(0.1, 0.1, 0.1);
	glPushMatrix();
	glTranslatef(0.5, -0.5, 0.3);
	glRotatef(90, 1, 0, 0);
	glScalef(0.3, 0.3, 0.3);
	glutSolidTorus(0.5, 0.6, 50, 50);
	glPopMatrix();

	glPopMatrix();
};