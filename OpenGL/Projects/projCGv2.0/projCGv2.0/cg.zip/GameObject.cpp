#include <iostream>

#include "GameObject.h"


void GameObject::draw(){

}

void GameObject::update(double delta_t){

}