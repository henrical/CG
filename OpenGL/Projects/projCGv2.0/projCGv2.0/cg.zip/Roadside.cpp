#include <iostream>

#include "Roadside.h"

Roadside::Roadside() {

}

Roadside::~Roadside(){

}

void Roadside::draw(){

}

void Roadside::roadsideSegment(Vector3 inicial,int numtorus, Vector3 direction){
	//ciclo para fazer segmentos de estrada
}