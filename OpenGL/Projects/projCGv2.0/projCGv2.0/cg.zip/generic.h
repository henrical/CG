/**
 * Library of generic functions.
 */

#ifndef _GENERIC_H_
#define _GENERIC_H_

//Converts an RGB value (0-255) to [0,1] scale required by OpenGL.
float changeScale(int RGB);

#endif