#ifndef _ROADSIDE_H_
#define __ROADSIDE_H_

#include "StaticObject.h"

class Roadside : public StaticObject {
public:
	Roadside();
	~Roadside();
	void draw();
	void roadsideSegment(Vector3 inicial, int numtorus, Vector3 direction);
};

#endif