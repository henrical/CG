#include <iostream>

#include "StaticObject.h"

StaticObject::StaticObject(){}

StaticObject::~StaticObject(){}