#include <iostream>

#include "GL/glut.h"
#include "LightSource.h"
#include "Car.h"

/**
 * Singleton GameManager class.
 * This class has only one instance.
 * 
 * How to use:
 * 
 * GameManager::instance()->key_pressed();
 *
 **/
class GameManager {

	//Private Variables
	private:
		static GameManager* _instance;
		int _gameObjects;
		LightSource _lightSources[10]; 
		int _cameras, camera;

	//Private Methods
	private:
		GameManager();
		~GameManager();

	//Public Methods and Functions
	public:
		static GameManager* instance()
		{
			if (!_instance) {
				_instance = new GameManager();

			}
			return _instance;
		}

		void addObject(); //TODO
		int getObjects(); //TODO

		int keyPressed(unsigned char key); //novo##########
		int onTimer(); //TODO
		int idle(); //TODO
		int update(); //TODO
		int init(); //TODO


		// #####################################//
		// Display and Reshape callback functions.
		void display();

		void reshape(int h, int w);

};