#include <iostream>

#include "GameManager.h"
#include "LightSource.h"

GameManager* GameManager::_instance = nullptr;

GameManager::GameManager()
{

	//memset(_lightSources, 0, sizeof _lightSources);
	_gameObjects = 0 ;
	camera = 1;
}

void GameManager::addObject()
{
	_gameObjects += 1;
}

int GameManager::getObjects()
{
	return _gameObjects;
}

void GameManager::display(){
	glClearDepth(1.0);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//		##########	camaras	################
	if (camera == 1){
		glViewport(0, 0, 800, 700);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		float rac = (float)800 / 700;
		if (rac > 1)
			glOrtho(rac*-3.0f, rac*3.0f, -3.0f, 3.0f, -5.0f, 5.0f);
		else glOrtho(-2.0f, 2.0f, -2.0f / rac, 2.0f / rac, -4.0f, 4.0f);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	}
	else if (camera == 2){
		glViewport(0, 0, 800, 700);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		float rac = (float)800 / 700;
		gluPerspective(90, rac, 0, 15);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		gluLookAt(0, -2, 0.007, 0, 0, 0, 0, 1, 0);
	}
	else if (camera == 3){
		glViewport(0, 0, 800, 700);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		float rac = (float)800 / 700;
		gluPerspective(90, rac, 0, 15);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		gluLookAt(0, -2.5, 1.5, 0, 0, 0, 0, 1, 0);
	}

	
	Car* c = new Car();
	std::cout << "---> Display" << std::endl;

	//Set clearing value.
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);		//porque � que esta aqui

	//Clear screen.
	glClear(GL_COLOR_BUFFER_BIT);		// esta um igual acima das camaras -^

	//		############	mesa	############
	glColor3f(0.968627451f, 1.0f, 0.3921568627f);//amarelo
	glScalef(1.5, 1.5, 1.5);
	glPushMatrix();
	glTranslatef(0.0, 0.0, -1.5);
	glutSolidCube(3);
	glPopMatrix();
	//	###########

	c->draw();


	glFlush();
}

int GameManager::keyPressed(unsigned char key){
	if (key == '2'){
		camera = 2;
	}
	else if (key == '1'){
		camera = 1;
	}
	else if (key == '3'){
		camera = 3;
	}
	return 0;
}

void GameManager::reshape(int h, int w){
	//alterar angulo da camara
	//gluPerspective();

	std::cout << "->Reshape" << std::endl;
	float top, right, bottom, left, near, far;
	float delta;

	left = 2., right = -2., bottom = 2., top = -2., near = -2., far = 2.;

	// Width Height Ratio
	float wh_ratio = (right - left) - (top - bottom);

	// Aspect ratio of the window
	float aspect = (float)w / h;

	//std::cerr << aspect << std::endl;

	// Set Viewport: start at (0,0)
	// and size of the whole window
	glViewport(0, 0, w, h);

	//Pushes Projection matrix to top of the stack.
	//Loads identity matrix.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//Pushes Model-View matrix to top of the stack.
	//Loads identity matrix.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Define  ortho projection.
	// Allow window resizing.
	if (aspect > wh_ratio)
	{
		delta = ((top - bottom) * aspect - (right - left)) / 2;

		glOrtho(left - delta, right + delta, bottom, top, near, far);

	}
	else {

		delta = ((top - bottom) / aspect - (right - left)) / 2;

		glOrtho(left, right, bottom - delta, top + delta, near, far);
	}
}