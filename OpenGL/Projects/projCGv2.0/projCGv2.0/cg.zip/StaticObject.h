#ifndef _STATIC_OBJECT_H_
#define _STATIC_OBJECT_H_

#include "GameObject.h"

class StaticObject : public GameObject {
	public:
		StaticObject();
		~StaticObject();
};

#endif